from telegram.ext import *
import main as R
def handle_messages(update,context):
    text = str(update.message.text)
    response = R.sample_main(text)
    update.message.reply_text(response)
updater = Updater('5703085243:AAF9qHqXI8EBE8IiTHEaj90WOkISHtfqqsA')
d = updater.dispatcher
d.add_handler(MessageHandler(Filters.text, handle_messages))
updater.start_polling()
updater.idle()