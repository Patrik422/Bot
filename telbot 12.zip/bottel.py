import arizona
"https://github.com/JakubVogal/TelegramBot.git"

arizona.post()
'https://api.telegram.org/bot5520317464:AAG2HajBOwW8zipb37-qXcgiaMY5iEZ3TB8/sendMessage?chat_id=-853617346&text=Change on %s'